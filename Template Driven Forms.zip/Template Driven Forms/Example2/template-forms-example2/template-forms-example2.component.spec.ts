import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateFormsExample2Component } from './template-forms-example2.component';

describe('TemplateFormsExample2Component', () => {
  let component: TemplateFormsExample2Component;
  let fixture: ComponentFixture<TemplateFormsExample2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateFormsExample2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateFormsExample2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
