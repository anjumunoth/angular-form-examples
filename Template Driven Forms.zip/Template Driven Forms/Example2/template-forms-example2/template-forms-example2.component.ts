import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-forms-example2',
  templateUrl: './template-forms-example2.component.html',
  styleUrls: ['./template-forms-example2.component.css']
})
export class TemplateFormsExample2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  model: any = {};

  onSubmit() {
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.model))
  }
}