import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-forms-example1',
  templateUrl: './template-forms-example1.component.html',
  styleUrls: ['./template-forms-example1.component.css']
})
export class TemplateFormsExample1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  genders = ['male', 'female'];
  
  userData = {
    username: '',
    email: '',
    country: '',
    gender: ''
  };
  submitted = false;
 
  
onSubmit(form,formData) {
    console.log('submitted formdata',formData);  
    
    alert('Form submitted successfully');
    
    form.reset();
  }
}