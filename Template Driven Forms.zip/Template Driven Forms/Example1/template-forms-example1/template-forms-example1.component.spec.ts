import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateFormsExample1Component } from './template-forms-example1.component';

describe('TemplateFormsExample1Component', () => {
  let component: TemplateFormsExample1Component;
  let fixture: ComponentFixture<TemplateFormsExample1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateFormsExample1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateFormsExample1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
