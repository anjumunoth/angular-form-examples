import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-forms-example4',
  templateUrl: './template-forms-example4.component.html',
  styleUrls: ['./template-forms-example4.component.css']
})
export class TemplateFormsExample4Component implements OnInit {

  model;  
  uName: string;
  movies: string[];
  cinemaHalls: string[];
  movieTimings: string[];
  submitted: boolean = false;
  
  constructor() { }
  
  ngOnInit() {
      this.uName = "";
      this.model = {movies:"Titanic", cinemaHalls:"Classic Cinemas",movieTimings: "21:30"};
      this.movies = ["Titanic", "Ice Age 3", "Jumanji"];
      this.cinemaHalls = ["Classic Cinemas", "NY Studios", "Mega Screens"];
      this.movieTimings = ["10:10", "13:40", "5:25", "21:30"];
  }

  onSubmit() {
    this.submitted = true;
  }
}


