import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateFormsExample4Component } from './template-forms-example4.component';

describe('TemplateFormsExample4Component', () => {
  let component: TemplateFormsExample4Component;
  let fixture: ComponentFixture<TemplateFormsExample4Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateFormsExample4Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateFormsExample4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
